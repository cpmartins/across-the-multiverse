function comSlider1110686() { 
var self = this; 
var g_HostRoot = "";
var g_TransitionTimeoutRef = null;
var g_CycleTimeout = 10;
var g_currFrame = 0;
var g_manualSwitch = 0;
var g_currDate = new Date(); var g_currTime = g_currDate.getTime();var g_microID = g_currTime + '-' + Math.floor((Math.random()*1000)+1); 
var g_InTransition = 0;var g_Navigation = 0;var g_CS3 = null;var g_Pending = -1;this.getCurrMicroID = function() { return g_microID; } 
this.comSLoadImgInFrame = function(frameid, src) 
{
     jqCS1110686("#comSImg1110686_"+frameid+" img").attr("src", src).load(function(){
         if (!this.complete || typeof this.naturalWidth == "undefined" || this.naturalWidth == 0)
         {
             //broken image
         }
     });
}
this.setNavStyle = function(id, background, color, border, type)
{
 if (background == "")
 {
     jqCS1110686("#comSNavigation1110686_"+id).css("background", "none");
 }
 else if (background == "transparent")
 {
     jqCS1110686("#comSNavigation1110686_"+id).css("background", "transparent");
 }
 else
 {
     jqCS1110686("#comSNavigation1110686_"+id).css("background", "#"+background);
 }
 if (color != "") { jqCS1110686("#comSNavigation1110686_"+id).css("color", "#"+color); }
 if (background == "transparent") { jqCS1110686("#comSNavigation1110686_"+id).css("border", border+"px solid transparent"); } else if (background != "") { jqCS1110686("#comSNavigation1110686_"+id).css("border", border+"px solid #"+background); } else { jqCS1110686("#comSNavigation1110686_"+id).css("border", border+"px"); } 
 var margin = (-1)*border;
 jqCS1110686("#comSNavigation1110686_"+id).css("margin-top", margin+"px");
 jqCS1110686("#comSNavigation1110686_"+id).css("margin-left", margin+"px");
 if (type == 0)
 {
   jqCS1110686("#comImgBullet1110686_"+id).show();
   jqCS1110686("#comImgBulletcurr1110686_"+id).hide();
 }
 else
 {
   jqCS1110686("#comImgBulletcurr1110686_"+id).show();
   jqCS1110686("#comImgBullet1110686_"+id).hide();
 }
}
this.targetClearTimeouts = function()
{
 if (g_TransitionTimeoutRef != null)     { window.clearTimeout(g_TransitionTimeoutRef); g_TransitionTimeoutRef = null;}
}
this.getNextFrame = function()
{
 var ret = g_currFrame;
 ret++;
 if (ret == 5) {ret = 0;}
 return ret;
}
this.getPrevFrame = function()
{
 var ret = g_currFrame;
 ret--;
 if (ret < 0) {ret = (5-1);}
 return ret;
}
this.switchFrame = function()
{
     g_Navigation = 1;
     var currFrame=g_currFrame;
     g_currFrame = self.getNextFrame();
     self.switchFromToFrame(currFrame, g_currFrame);
}
 
this.switchFramePrev = function()
{
     g_Navigation = 0;
     var currFrame=g_currFrame;
     g_currFrame = self.getPrevFrame();
     self.switchFromToFrame(currFrame, g_currFrame);
}
 
this.switchToFrame = function(toFrame)
{
     if ((g_InTransition == 1) || ((g_currFrame == toFrame) && (g_currFrame != g_Pending)))
     {
         if (g_currFrame == toFrame) { return false; }
         g_Pending = toFrame;     }
     var currFrame=g_currFrame;
     g_currFrame=toFrame;
     if (currFrame < g_currFrame)
         g_Navigation = 0;
     else
         g_Navigation = 1;
     self.switchFromToFrame(currFrame, g_currFrame);
}
 
this.switchFromToFrame =  function(currFrame, toFrame)
{
     if (g_InTransition == 1)
     {
         g_Pending = toFrame;  self.setNavStyle(currFrame, 'transparent','DDDDDD',0, 0);  self.setNavStyle(toFrame, '555555','383838',1, 1);         return false;
     }
g_InTransition = 1;
g_manualSwitch = 1;
 g_CS3.slideTo(toFrame); self.setNavStyle(currFrame, 'transparent','DDDDDD',0, 0); self.setNavStyle(toFrame, '555555','383838',1, 1);     
     
     
     
}
this.initFrame = function()
{
g_currFrame = 0;
g_manualSwitch = 0;
 g_CS3 = jqCS1110686("#cs31110686").cs3({
                                                    effects: 'galaxy',
													preloader: false,													
													/*touch : {enabled : true,  effect: 'galaxy'},*/
													preloadOnlyFirst: true,					callbacks: { onTransitionStart : function() {
														g_InTransition=1;
														if (g_manualSwitch == 0)
														{
															var g_currFrame = g_CS3.h.indexes().active;
															var currFrame = g_currFrame;
															toFrame = self.getNextFrame();
															g_currFrame = toFrame;  self.setNavStyle(currFrame, 'transparent','DDDDDD',0, 0);  self.setNavStyle(toFrame, '555555','383838',1, 1);						}																										
													}, onTransitionEnd : function() { if (g_microID !=objcomSlider1110686.getCurrMicroID()){return false;};	g_manualSwitch = 0;																
									//
									if (g_Pending != -1) 
									{
										setTimeout(function(){ g_currFrame = g_CS3.h.indexes().active; g_InTransition=0;  self.switchToFrame(g_Pending); g_Pending = -1; }, 100);															
									}
									else
									{
										g_currFrame = g_CS3.h.indexes().active;
										g_InTransition=0; 														
									}					
								  }} 
                                 });if (g_microID !=objcomSlider1110686.getCurrMicroID()){return false;};self.setNavStyle(g_CS3.h.indexes().active, '555555','383838',1, 1);
jqCS1110686("#comSFrameWrapper1110686_ .cs3-active-slide").css('display', 'block');  return true;
}

					this.scriptLoaded = function(options)
					{
				   jqCS1110686 = jQuery1110686.noConflict(false);jqCS1110686("#comslider_in_point_1110686").html('<div id="comSWrapper1110686_" name="comSWrapper1110686_" style="display: inline-block; text-align: center; border:0px; width:687px; height:335px; position: relative; top: 0px; left: 0px;"><div id="comSWrapper1110686_" name="comSWrapper1110686_" style="background:#000000;border:0px; width:687px; height:335px; "><div id="comSFrameWrapper1110686_" name="comSFrameWrapper1110686_" style="position: absolute; top: 0px; left: 0px;"><div class="cs3-wrap cs3-skin-no"><div id="cs31110686" class="cs3" style="width:687px; height:304px;"><div class="cs3-slide"><div id="comSFrameSek1110686_0" name="comSFrameSek1110686_0" style="position:absolute; overflow:hidden; top:0px; left:0px; width:687px; height:304px;"><div id="comSImg1110686_0" name="comSImg1110686_0" style="position:absolute; overflow:hidden; top:0px; left:0px; width:687px; height:304px;"><img style="border:0px; width:456px; height:304px;" src="comslider1110686/img/160908174620101.jpg"></img></div></div></div><div class="cs3-slide"><div id="comSFrameSek1110686_1" name="comSFrameSek1110686_1" style="position:absolute; overflow:hidden; top:0px; left:0px; width:687px; height:304px;"><div id="comSImg1110686_1" name="comSImg1110686_1" style="position:absolute; overflow:hidden; top:0px; left:0px; width:687px; height:304px;"><img style="border:0px; width:304px; height:304px;" src="comslider1110686/img/160908182749102.png"></img></div></div></div><div class="cs3-slide"><div id="comSFrameSek1110686_2" name="comSFrameSek1110686_2" style="position:absolute; overflow:hidden; top:0px; left:0px; width:687px; height:304px;"><div id="comSImg1110686_2" name="comSImg1110686_2" style="position:absolute; overflow:hidden; top:0px; left:0px; width:687px; height:304px;"><img style="border:0px; width:540px; height:304px;" src="comslider1110686/img/160908174620107.jpg"></img></div></div></div><div class="cs3-slide"><div id="comSFrameSek1110686_3" name="comSFrameSek1110686_3" style="position:absolute; overflow:hidden; top:0px; left:0px; width:687px; height:304px;"><div id="comSImg1110686_3" name="comSImg1110686_3" style="position:absolute; overflow:hidden; top:0px; left:0px; width:687px; height:304px;"><img style="border:0px; width:687px; height:232px;" src="comslider1110686/img/160908174620105.jpg"></img></div></div></div><div class="cs3-slide"><div id="comSFrameSek1110686_4" name="comSFrameSek1110686_4" style="position:absolute; overflow:hidden; top:0px; left:0px; width:687px; height:304px;"><div id="comSImg1110686_4" name="comSImg1110686_4" style="position:absolute; overflow:hidden; top:0px; left:0px; width:687px; height:304px;"><img style="border:0px; width:380px; height:304px;" src="comslider1110686/img/160908182749101.jpg"></img></div></div></div></div></div></div><a name="0" style="cursor:pointer; text-decoration:none !important; font-size:12px;" href=""><div id="comSNavigation1110686_0" name="comSNavigation1110686_0" style="border-radius: 32px; margin-left:0px; margin-top:0px; border: 0px solid transparent; position:absolute; height:16px; width:16px; top:314px; left:293px; z-index: 5; text-align: center; vertical-align:bottom;  color: #DDDDDD;background: transparent; "><div id="height_workaround" style="font-size:1px;line-height:0;height:16px;">&nbsp;<img style="position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBullet1110686_0" name="comImgBullet1110686_0" src="comslider1110686/imgnav/nav2.png?timstamp=1473356795" /><img style="display: none; position: absolute; position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBulletcurr1110686_0" name="comImgBulletcurr1110686_0" src="comslider1110686/imgnav/navs2.png?timstamp=1473356795" /></div></div></a><script type="text/javascript"> jqCS1110686("#comSNavigation1110686_0").fadeTo(0,0.7);</script><a name="1" style="cursor:pointer; text-decoration:none !important; font-size:12px;" href=""><div id="comSNavigation1110686_1" name="comSNavigation1110686_1" style="border-radius: 32px; margin-left:0px; margin-top:0px; border: 0px solid transparent; position:absolute; height:16px; width:16px; top:314px; left:314px; z-index: 5; text-align: center; vertical-align:bottom;  color: #DDDDDD;background: transparent; "><div id="height_workaround" style="font-size:1px;line-height:0;height:16px;">&nbsp;<img style="position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBullet1110686_1" name="comImgBullet1110686_1" src="comslider1110686/imgnav/nav2.png?timstamp=1473356795" /><img style="display: none; position: absolute; position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBulletcurr1110686_1" name="comImgBulletcurr1110686_1" src="comslider1110686/imgnav/navs2.png?timstamp=1473356795" /></div></div></a><script type="text/javascript"> jqCS1110686("#comSNavigation1110686_1").fadeTo(0,0.7);</script><a name="2" style="cursor:pointer; text-decoration:none !important; font-size:12px;" href=""><div id="comSNavigation1110686_2" name="comSNavigation1110686_2" style="border-radius: 32px; margin-left:0px; margin-top:0px; border: 0px solid transparent; position:absolute; height:16px; width:16px; top:314px; left:335px; z-index: 5; text-align: center; vertical-align:bottom;  color: #DDDDDD;background: transparent; "><div id="height_workaround" style="font-size:1px;line-height:0;height:16px;">&nbsp;<img style="position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBullet1110686_2" name="comImgBullet1110686_2" src="comslider1110686/imgnav/nav2.png?timstamp=1473356795" /><img style="display: none; position: absolute; position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBulletcurr1110686_2" name="comImgBulletcurr1110686_2" src="comslider1110686/imgnav/navs2.png?timstamp=1473356795" /></div></div></a><script type="text/javascript"> jqCS1110686("#comSNavigation1110686_2").fadeTo(0,0.7);</script><a name="3" style="cursor:pointer; text-decoration:none !important; font-size:12px;" href=""><div id="comSNavigation1110686_3" name="comSNavigation1110686_3" style="border-radius: 32px; margin-left:0px; margin-top:0px; border: 0px solid transparent; position:absolute; height:16px; width:16px; top:314px; left:356px; z-index: 5; text-align: center; vertical-align:bottom;  color: #DDDDDD;background: transparent; "><div id="height_workaround" style="font-size:1px;line-height:0;height:16px;">&nbsp;<img style="position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBullet1110686_3" name="comImgBullet1110686_3" src="comslider1110686/imgnav/nav2.png?timstamp=1473356795" /><img style="display: none; position: absolute; position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBulletcurr1110686_3" name="comImgBulletcurr1110686_3" src="comslider1110686/imgnav/navs2.png?timstamp=1473356795" /></div></div></a><script type="text/javascript"> jqCS1110686("#comSNavigation1110686_3").fadeTo(0,0.7);</script><a name="4" style="cursor:pointer; text-decoration:none !important; font-size:12px;" href=""><div id="comSNavigation1110686_4" name="comSNavigation1110686_4" style="border-radius: 32px; margin-left:0px; margin-top:0px; border: 0px solid transparent; position:absolute; height:16px; width:16px; top:314px; left:377px; z-index: 5; text-align: center; vertical-align:bottom;  color: #DDDDDD;background: transparent; "><div id="height_workaround" style="font-size:1px;line-height:0;height:16px;">&nbsp;<img style="position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBullet1110686_4" name="comImgBullet1110686_4" src="comslider1110686/imgnav/nav2.png?timstamp=1473356795" /><img style="display: none; position: absolute; position: absolute; top: 0px; left: 0px; border:0px;" id="comImgBulletcurr1110686_4" name="comImgBulletcurr1110686_4" src="comslider1110686/imgnav/navs2.png?timstamp=1473356795" /></div></div></a><script type="text/javascript"> jqCS1110686("#comSNavigation1110686_4").fadeTo(0,0.7);</script></div><div id="comSNavigationControl1110686__back" name="comSNavigationControl1110686__back" style="display: none; cursor: pointer; margin: 0px; margin-left:10px; border: 0px; position:absolute; height:48px; width:48px; top:128px; left:0px; z-index: 6; text-align: center; vertical-align:bottom;  background-color: transparent; "><img class="def" style="position: absolute; top: 0px; left: 0px; border: 0px;" src="comslider1110686/imgnavctl/defback.png?1473356655" /><img class="hover" style="position: absolute; top: 0px; left: 0px; display:none; border: 0px;" src="comslider1110686/imgnavctl/defbackhover.png?1473356655" /></div><script type="text/javascript"> jqCS1110686("#comSNavigationControl1110686__back").bind(\'mouseenter\', function() {  jqCS1110686(this).css(\'background-color\', \'transparent\'); jqCS1110686("#comSNavigationControl1110686__back img.hover").show(); jqCS1110686("#comSNavigationControl1110686__back img.def").hide(); });</script><script type="text/javascript"> jqCS1110686("#comSNavigationControl1110686__back").bind(\'mouseleave\', function() {  jqCS1110686(this).css(\'background-color\', \'transparent\'); jqCS1110686("#comSNavigationControl1110686__back img.def").show();  jqCS1110686("#comSNavigationControl1110686__back img.hover").hide(); });</script><script type="text/javascript"> jqCS1110686("#comSNavigationControl1110686__back").bind(\'click\', function() { objcomSlider1110686.switchFramePrev(); });</script><div id="comSNavigationControl1110686__forward" name="comSNavigationControl1110686__forward" style="display: none; cursor: pointer; margin: 0px; margin-left:-10px; border: 0px; position:absolute; height:48px; width:48px; top:128px; left:639px; z-index: 6; text-align: center; vertical-align:bottom; background-color: transparent; "><img class="def" style="position: absolute; top: 0px; left: 0px; border: 0px;" src="comslider1110686/imgnavctl/defforward.png?1473356655" /><img class="hover" style="position: absolute; top: 0px; left: 0px; display:none; border: 0px;" src="comslider1110686/imgnavctl/defforwardhover.png?1473356655" /></div><script type="text/javascript"> jqCS1110686("#comSNavigationControl1110686__forward").bind(\'mouseenter\', function() {  jqCS1110686(this).css(\'background-color\', \'transparent\'); jqCS1110686("#comSNavigationControl1110686__forward img.hover").show(); jqCS1110686("#comSNavigationControl1110686__forward img.def").hide(); });</script><script type="text/javascript"> jqCS1110686("#comSNavigationControl1110686__forward").bind(\'mouseleave\', function() {  jqCS1110686(this).css(\'background-color\', \'transparent\'); jqCS1110686("#comSNavigationControl1110686__forward img.def").show();  jqCS1110686("#comSNavigationControl1110686__forward img.hover").hide(); });</script><script type="text/javascript"> jqCS1110686("#comSNavigationControl1110686__forward").bind(\'click\', function() { objcomSlider1110686.switchFrame(); });</script><script type="text/javascript">jqCS1110686("#comSWrapper1110686_").bind(\'mouseenter\', function() { jqCS1110686("#comSNavigationControl1110686__back").fadeTo("fast",0.8);jqCS1110686("#comSNavigationControl1110686__forward").fadeTo("fast",0.8); });</script><script type="text/javascript">jqCS1110686("#comSWrapper1110686_").bind(\'mouseleave\', function() { jqCS1110686("#comSNavigationControl1110686__back").fadeOut("fast");jqCS1110686("#comSNavigationControl1110686__forward").fadeOut("fast"); });</script></div>');
                    jqCS1110686("#comslider_in_point_1110686 a").bind('click',  function() { if ((this.name.length > 0) && (isNaN(this.name) == false)) {  self.switchToFrame(parseInt(this.name)); return false;} });
                self.initFrame();

}
var g_CSIncludes = new Array();
var g_CSLoading = false;
var g_CSCurrIdx = 0; 
 this.include = function(src, last) 
                {
                    if (src != '')
                    {				
                            var tmpInclude = Array();
                            tmpInclude[0] = src;
                            tmpInclude[1] = last;					
                            //
                            g_CSIncludes[g_CSIncludes.length] = tmpInclude;
                    }            
                    if ((g_CSLoading == false) && (g_CSCurrIdx < g_CSIncludes.length))
                    {


                            var oScript = null;
                            if (g_CSIncludes[g_CSCurrIdx][0].split('.').pop() == 'css')
                            {
                                oScript = document.createElement('link');
                                oScript.href = g_CSIncludes[g_CSCurrIdx][0];
                                oScript.type = 'text/css';
                                oScript.rel = 'stylesheet';

                                oScript.onloadDone = true; 
                                g_CSLoading = false;
                                g_CSCurrIdx++;								
                                if (g_CSIncludes[g_CSCurrIdx-1][1] == true) 
                                        self.scriptLoaded(); 
                                else
                                        self.include('', false);
                            }
                            else
                            {
                                oScript = document.createElement('script');
                                oScript.src = g_CSIncludes[g_CSCurrIdx][0];
                                oScript.type = 'text/javascript';

                                //oScript.onload = scriptLoaded;
                                oScript.onload = function() 
                                { 
                                        if ( ! oScript.onloadDone ) 
                                        {
                                                oScript.onloadDone = true; 
                                                g_CSLoading = false;
                                                g_CSCurrIdx++;								
                                                if (g_CSIncludes[g_CSCurrIdx-1][1] == true) 
                                                        self.scriptLoaded(); 
                                                else
                                                        self.include('', false);
                                        }
                                };
                                oScript.onreadystatechange = function() 
                                { 
                                        if ( ( "loaded" === oScript.readyState || "complete" === oScript.readyState ) && ! oScript.onloadDone ) 
                                        {
                                                oScript.onloadDone = true;
                                                g_CSLoading = false;	
                                                g_CSCurrIdx++;
                                                if (g_CSIncludes[g_CSCurrIdx-1][1] == true) 
                                                        self.scriptLoaded(); 
                                                else
                                                        self.include('', false);
                                        }
                                }
                                
                            }
                            //
                            document.getElementsByTagName("head").item(0).appendChild(oScript);
                            //
                            g_CSLoading = true;
                    }

                }
                

}
objcomSlider1110686 = new comSlider1110686();
objcomSlider1110686.include('comslider1110686/js/helpers.js', false);
objcomSlider1110686.include('comslider1110686/js/idangerous.chopslider-3.4.css', false);
objcomSlider1110686.include('comslider1110686/js/jquery-1.10.1.js', false);
objcomSlider1110686.include('comslider1110686/js/jquery-ui-1.10.3.effects.js', false);
objcomSlider1110686.include('comslider1110686/js/idangerous.chopslider-3.4.min.js', true);
