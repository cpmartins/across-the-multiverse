document.write('<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"');
document.write('codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="301" height="212">');
document.write('<param name="movie" value="musicplayer.swf?playlist=playlist.php" />');
document.write('<param name="quality" value="high" />');
document.write('<param name="wmode" value="transparent" />');
document.write('<embed src="musicplayer.swf?playlist=playlist.php" quality="high" wmode="transparent"');
document.write('pluginspage="http://www.macromedia.com/go/getflashplayer"');
document.write('type="application/x-shockwave-flash" width="301" height="212">');
document.write('</embed></object>');
