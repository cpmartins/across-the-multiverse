Amazing Audio Player
Version 3.4
Copyright 2016 Magic Hills Pty Ltd
http://amazingaudioplayer.com/


Overview
-----------------------------------------------------------------------

Amazing Audio Player is an easy-to-use Windows & Mac app that enables you to create HTML5 audio player for your website. The music player works on iPhone, iPad, Android and all modern web browsers including Firefox, Chrome, Opera, Safari, Internet Explorer 7, 8, 9, 10 and 11.

What's New

Version 3.4
- Remove the "Allow to run Adobe Flash" alert on Firefox when the Flash plugin is configured as "Ask to Activate"
- Fix a bug in Flash mode
- Add a class amazingaudioplayer-track-item-hoverover to the track list text when the mouse is on top of the item

Version 3.3
- Add an option to use Flash ad default player
- Add an option to force using HTML5 and no Flash object will be initialized

Version 3.2
- Fix a bug in Joomla module

Version 3.1
- Fix a bug in WordPress plugin

Version 3.0
- Support URL parameters firstaudioid and autoplayaudio

Version 2.9
- Fix minor bugs

Version 2.8
- Fix minor bugs

Version 2.7
- Support playing remote URL
- Support live streaming
- The player is now responsive
- Create full width player
- Move page navigation arrows to bottom of the tracklist

Version 2.6
- Support add download links in player tracklist

Version 2.5
- Fix a minor bug on Firefox

Version 2.4
- Support apostrophe and quotation mark in title
- Change the width of skin DarkBox, JukeBox, MusicBox and LightBox to 300px
- Add a button in Add Audios dialog to apply artist, album and thumbnail image information to all other audios


Version 2.3
- Add an option to force Firefox using Flash

Version 2.2
- Fix a minor bug in the player

Version 2.1
- Add three single play/pause button skins (commercial version only)

Version 2.0
- Save publish options to project files
- Add an option to disable title scrolling in player bar
- Fix a bug of icons not displaying on some computers

Version 1.9
- Support embedding the player to webpage using iframe

Version 1.8
- Fix the bug of random playing
- Add an option to stop other audio players on the same webpage when playing

Version 1.7
- Fix the bug of random playing
- Add an option of not continuous playing
- Add an option of not preloading first audio on startup
- Add an option to setup default volume

Version 1.6
- Fix the bug of autoplay
- Fix the bug of adding background image
- Support API and events

Version 1.5
- Fix the bug of replacing multiple macro variables %ID%

Version 1.4
- Fix the bug of can not import some mp3 files

Version 1.3
- Fix the bug of duration moving down to next line in playlist under Firefox
- Add an option to create standalone WordPress plugin

Version 1.2
- Fix a bug of playing OGG in Firefox
- Add a progess bar for skin DarkBox

Version 1.1
- Add a new skin DarkBox

Version 1.0
- First public version released

Links
-----------------------------------------------------------------------

Download Free Versions for Windows and Mac:  http://amazingaudioplayer.com/downloads/
Online Examples:  http://amazingaudioplayer.com/examples/
Upgrade to Commercial Versions:  http://amazingaudioplayer.com/order/
Quick Start Guide:  http://amazingaudioplayer.com/help/
Contact Us: http://amazingaudioplayer.com/contact/